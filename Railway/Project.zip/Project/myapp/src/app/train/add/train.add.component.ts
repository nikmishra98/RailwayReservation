import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TrainService } from '../train.service';

@Component({
  selector: 'app-train-add',
  templateUrl: './train.add.component.html',
  styleUrls: ['./train.add.component.css']
})

export class TrainAddComponent implements OnInit {

  train = []

  Train_no = 0     
  Train_name = ''  
  No_of_coaches = 0
  Source = ''       
  Destination = ''  
  Duration = 0
 
   constructor(
     private router: Router,
     private trainService: TrainService) {}
 
   ngOnInit() { }
 
   onAdd() {
     if(this.Train_no == 0){
         alert('Enter the valid train number')
     }else if(this.Train_name.length == 0){
         alert('Enter a valid train name')
     }else if(this.No_of_coaches == 0){
         alert('Enter valid coaches')
     }else if(this.Source.length == 0){
         alert('Enter valid source name')
     }else if(this.Destination.length == 0){
         alert('Enter valid destination name')
     }else if(this.Duration == 0){
         alert('Enter valid field')
     } else {
        this.trainService
       .addTrain(this.Train_no, this.Train_name, this.No_of_coaches, this.Source, this.Destination, this.Duration)
       .subscribe(response => {
         if (response['status'] == 'success') {
           alert('added train successfully')
           this.router.navigate(['/app-train-list'])
         } else {
           console.log(response['error'])
         }
       })
    }  
   }
}

