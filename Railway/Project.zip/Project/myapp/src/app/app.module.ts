import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { UserService } from './admin/admin.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'
import { AdminLoginComponent } from './admin/login/admin.login.component';
import { AdminRegisterComponent } from './admin/register/admin.register.component';
import { RouterModule, Route } from '@angular/router'
import { TrainAddComponent } from './train/add/train.add.component';
import { TrainService } from './train/train.service';
import { TrainListComponent } from './train/list/train.list.component';
import { TicketAddComponent } from './ticket/add/ticket.add.component';
import { TicketListComponent } from './ticket/list/ticket.list.component';
import { TicketService } from './ticket/ticket.service'
import { HomePageComponent } from './home/mainPage/home.mainPage.component';
import { HomeService } from './home/home.services';
import { CoachListComponent } from './coach/list/coach.list.component';
import { CoachService } from './coach/coach.services';
import { SearchTrainService } from './search/search.service';
import { SearchTrainComponent } from './search/train/search.train.component'
import { UserUpdateProfileComponent } from './admin/update-profile/admin.update-profile.component';

//import { HomeService } from './home/home.service';


const routes: Route[] = [
 // { path: '', component: AppComponent },
  {path: '', component: HomePageComponent},
  { path: 'app-login', component: AdminLoginComponent },
  { path: 'app-register', component: AdminRegisterComponent },
  { path: 'app-train-add', component: TrainAddComponent,canActivate: [UserService]},
  { path: 'app-train-list', component: TrainListComponent,canActivate: [UserService] },
  { path: 'app-ticket-list', component: TicketListComponent,canActivate: [UserService]},
  { path: 'app-ticket-add', component: TicketAddComponent,canActivate: [UserService]},
  { path: 'app-coach-list', component: CoachListComponent,canActivate: [UserService]},
  { path: 'app-search-train', component: SearchTrainComponent},
  { path: 'app-update-profile', component: UserUpdateProfileComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    AdminLoginComponent,
    AdminRegisterComponent,
    TrainAddComponent,
    TrainListComponent,
    TicketAddComponent,
    TicketListComponent,
    HomePageComponent,
    CoachListComponent,
    SearchTrainComponent,
    UserUpdateProfileComponent
 ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [
    UserService,
    TrainService,
    TicketService,
    HomeService,
    CoachService,
    SearchTrainService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
