import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SearchTrainService } from '../search.service';

@Component({
    selector: 'app-search-train',
    templateUrl: './search.train.component.html',
    styleUrls: ['./search.train.component.css']
})

export class SearchTrainComponent implements OnInit {
    Source = ''
    Destination = ''
    train:string
    trains = []
    stations = []
    station:string
    stations1 = []
    station1:string
    constructor(private searchService: SearchTrainService,
        private router: Router) { 
            this.searchService
            .getSourceStations()
            .subscribe(response => {
                if (response['status'] == 'success') {
                    this.trains = response['data']
                    this.train = this.trains[0].Source
                 } else {
                   console.log(response['error'])
                 }
            })

            this.searchService
            .getDestinationStations()
            .subscribe(response => {
                if (response['status'] == 'success') {
                  this.stations = response['data']
                  this.station = this.stations[0].Destination
                 } else {
                   console.log(response['error'])
                 }
            })
        }

    ngOnInit() { }

    
    onFind(Source:string,Destination:string){
        this.searchService
       .getTrains(this.Source,this.Destination)
       .subscribe(response => {
         if (response['status'] == 'success') {
            this.trains = response['data']
         } else {
           console.log(response['error'])
         }
       })
    }

    onBook(){
        this.router.navigate(['/app-login'])
    }
}