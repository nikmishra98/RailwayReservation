import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'

@Injectable()
export class SearchTrainService{

    url = 'http://localhost:5000/search-train'

    constructor(private http: HttpClient){}

      getSourceStations() {
        return this.http.get('http://localhost:5000/search-train/getSource')
      }
      getTrains(Source:string,Destination:string) {
        return this.http.get(this.url + '/' + Source + '/' + Destination)
      }
      getDestinationStations() {
        return this.http.get('http://localhost:5000/search-train/getDest')
      }
}