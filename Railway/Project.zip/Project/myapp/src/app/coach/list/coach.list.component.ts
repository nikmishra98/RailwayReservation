import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CoachService } from '../coach.services';

@Component({
    selector: 'app-coach-list',
    templateUrl: 'coach.list.component.html'
})

export class CoachListComponent implements OnInit {
    coaches = []
    constructor(private router: Router,
        private coachService: CoachService) { 
        this.coachService
        .getAllCoach()
        .subscribe(response=>{
            if (response['status'] == 'success') {
              this.coaches = response['data']
            } else {
              console.log(response['error'])
            }
        })
    }

    getCoaches(){
        this.coachService.get()
      .subscribe((response) => {
        if (response['status'] == 'success') {
          this.coaches = response['data']
        } else {
          alert('error occured:')
          console.log(response['error'])
        }
      })
    }

    onDelete(Coach_no: number) {

        const answer = confirm("Are you sure you want to delete this coach?")
        if (answer) {
          this.coachService
            .delete(Coach_no)
            .subscribe(response => {
              if (response['status'] == 'success') {
                alert('Deleted coach')
                this.getCoaches()
              } else {
                alert('Error while deleting the coach')
              }
            })
        }
      }

    ngOnInit() { }
    onLogout() {
      // remove the login status
      // sessionStorage.removeItem('login_status')
      localStorage.removeItem('login_status')
      localStorage.removeItem('Email')
      localStorage.removeItem('UserID')
    }
}