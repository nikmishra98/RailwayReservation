import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'

@Injectable()
export class CoachService{
  
    url = 'http://localhost:5000/coach'

    constructor(private http: HttpClient){}

    get(){
      return this.http.get(this.url)
    }

    getAllCoach() {
        return this.http.get(this.url)
      }

      delete(Position_from_Engine: number) {
        return this.http.delete(this.url + '/' + Position_from_Engine)
  
      }
}

