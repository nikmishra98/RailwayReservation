import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'

@Injectable()
export class TicketService{
  
    url = 'http://localhost:5000/ticket'

    url1 = 'http://localhost:5000/ticket/getCoach'
    constructor(private http: HttpClient){}

    get() {
      return this.http.get(this.url)
    }
    getTicket(){
        return this.http.get(this.url)
    }
    getAllTicket() {
        return this.http.get(this.url)
      }

    getCoach(){
      return this.http.get(this.url1)
    }
    addTicket(PNR_No: string,Ticket_no: number,No_of_seats: number,Source_Departure_Time: string,
        Destination_Arrival_Time: string,Fare: number,Coach_name: string,Train_no: number,Coach_no:string
        ) {
  
      const body = new FormData()
      body.append('PNR_No',PNR_No)
      body.append('Ticket_no','' + Ticket_no)
      body.append('No_of_seats','' + No_of_seats)
      body.append('Source_Departure_Time',Source_Departure_Time)
      body.append('Destination_Arrival_Time',Destination_Arrival_Time)
      body.append('Fare',''+ Fare)
      body.append('Coach_name',Coach_name)
      body.append('Train_no','' + Train_no)
      body.append('Coach_no',Coach_no)
  
      return this.http.post(this.url, body)
    }

    delete(Ticket_no: number) {
      return this.http.delete(this.url + '/' + Ticket_no)

    }

    update(Ticket_no: number,Coach_no:string,Fare: number){
      const body = {
        Coach_no:Coach_no,
        Fare:Fare
      }
      return this.http.put(this.url + '/' + Ticket_no,body)
    }
}

