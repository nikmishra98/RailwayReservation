import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TicketService } from '../ticket.service';

@Component({
  selector: 'app-ticket-add',
  templateUrl: './ticket.add.component.html',
  styleUrls: ['./ticket.add.component.css']
})

export class TicketAddComponent implements OnInit {

  tickets = []
  coachTypes = []
  coachType:string

 PNR_No = ''    
 Ticket_no = 0 
 No_of_seats = 0
 Source_Departure_Time = ''       
 Destination_Arrival_Time = ''  
 Fare = 0
 Coach_name = ''
 Train_no = 0
 Coach_no = ''

  constructor(
    private router: Router,
    private ticketService: TicketService) {
        this.ticketService
        .getCoach()
        .subscribe(response => {

          if(response['status'] == 'success'){
            this.coachTypes = response['data']
            this.coachType = this.coachTypes[0].Coach_name
            console.log(this.coachType)
          }else{
            console.log(response['error'])
          }
        })
      }

  ngOnInit() { }

  getTickets() {
    this.ticketService.get()
      .subscribe((response) => {
        if (response['status'] == 'success') {
          this.tickets = response['data']
        } else {
          alert('error occured:')
          console.log(response['error'])
        }
      })
  }
  onAdd() {
    if(this.PNR_No.length == 0){
        alert('Enter valid PNR number')
    }else if(this.Ticket_no == 0){
        alert('Enter a valid ticket number')
    }else if(this.No_of_seats == 0){
        alert('Enter valid coaches')
    }else if(this.Source_Departure_Time.length == 0){
        alert('Enter valid source departure time')
    }else if(this.Destination_Arrival_Time.length == 0){
        alert('Enter valid destination arrival time')
    }else if(this.Fare == 0){
        alert('Enter valid field')
    }else if(this.Coach_name.length == 0){
      alert('Enter valid coach name')
    }else if(this.Train_no == 0){
      alert('Enter valid coach name')
    }else {
       this.ticketService
      .addTicket(this.PNR_No, this.Ticket_no, this.No_of_seats, this.Source_Departure_Time, this.Destination_Arrival_Time, this.Fare,this.Coach_name,this.Train_no,this.Coach_no)
      .subscribe(response => {
        if (response['status'] == 'success') {
          alert('Ticket added successfully....!!!!')
          this.router.navigate(['/app-ticket-list'])
        } else {
          console.log(response['error'])
        }
      })
   }  
  }
  onUpdate(Ticket_no:number){
    this.ticketService
    .update(this.Ticket_no,this.Coach_no,this.Fare)
    .subscribe(response => {
      if (response['status'] == 'success') {
        this.router.navigate(['/app-ticket-list'])
        this.getTickets()
      } else {
        alert('Error while updating ticket')
      }
    })
  }
}

