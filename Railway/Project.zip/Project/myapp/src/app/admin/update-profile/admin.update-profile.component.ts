import { Component, OnInit } from '@angular/core';
import { UserService } from '../admin.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-update-profile',
  templateUrl: './admin.update-profile.component.html',
  styleUrls: ['./admin.update-profile.component.css']
})

export class UserUpdateProfileComponent {
  UserID = 0
  First_Name = ''
  Last_Name = ''
  Age = 0
  Email = ''
  Password = ''
  MobileNumber = ''
  Address = ''
  componentToLaunch = 'app-update-profile-'

  constructor(
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private userService: UserService) { 
      console.log(activatedRoute.snapshot.queryParams)
    this.componentToLaunch = activatedRoute.snapshot.queryParams['screen']
    }
    
    onUpdate(UserID:number){
      const answer = confirm("Are you sure you want to update?")
      if (answer) {
              this.userService
              .update(this.UserID,this.First_Name,this.Last_Name,this.Age,this.Email,this.Password,this.MobileNumber,this.Address)
              .subscribe(response => {
                console.log(response['data'].UserID)
                if (response['status'] == 'success') {
                  this.route.navigate(['/app-ticket-list'])
                } else {
                  alert('Error while updating user profile')
                }
              })
            }
      }
  onLogout() {
    // remove the login status
    // sessionStorage.removeItem('login_status')
    localStorage.removeItem('login_status')
    localStorage.removeItem('Email')
    localStorage.removeItem('UserID')
    this.route.navigate(['/app-login'])
  }
}
