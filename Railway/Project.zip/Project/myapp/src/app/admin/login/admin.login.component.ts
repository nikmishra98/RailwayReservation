import { Component, OnInit } from '@angular/core';
import { UserService } from '../admin.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './admin.login.component.html',
  styleUrls: ['./admin.login.component.css']
})

export class AdminLoginComponent {
  Email = ''
  Password = ''
  componentToLaunch = 'app-train-add-'

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private userService: UserService) { 
      console.log(activatedRoute.snapshot.queryParams)
    this.componentToLaunch = activatedRoute.snapshot.queryParams['screen']
    }


  onLogin() {
    if (this.Email.length == 0) {
      alert('enter valid email')
    } else if (this.Password.length == 0) {
      alert('enter valid password')
    } else {
      this.userService
        .login(this.Email,this.Password)
        .subscribe(response => {
          if (response['status'] == 'success') {
            alert('authenticated')
            console.log(response['data'].Role)
            if(response['data'].Role == 'user'){
            localStorage['login_status'] = '1'
            localStorage['Email'] = response['data']['Email']
            localStorage['UserID'] = response['data']['UserID']
            this.router.navigate(['/app-ticket-list'])
            }else if(response['data'].Role == 'admin'){
            localStorage['login_status'] = '1'
            localStorage['Email'] = response['data']['Email']
            localStorage['UserID'] = response['data']['UserID']
            this.router.navigate(['/app-train-list'])
            }
            /*if(TrainService){
              this.router.navigate(['/app-train-list'])}
              else{
                this.router.navigate(['/app-ticket-list'])
              }*/
          } else {
            alert(response['error'])
          }
        })
    }
  }

}
