const db = require('./db')
const express = require('express')
const utils = require('./utils')
const multer = require('multer')
const upload = multer({ dest: 'thumbnails/'})

const router = express.Router()

router.get('/', (request, response) => {
    const connection = db.connect()
    const statement = `select * from Ticket`
    connection.query(statement, (error, data) => {
        connection.end()
        const users = []
        for (let index = 0; index < data.length; index++) {
            const ticket = data[index]
            users.push({
                PNR_No: ticket['PNR_No'],
                Ticket_no: ticket['Ticket_no'],
                No_of_seats: ticket['No_of_seats'],
                Source_Departure_Time: ticket['Source_Departure_Time'],
                Destination_Arrival_Time: ticket['Destination_Arrival_Time'],
                Fare: ticket['Fare'],
                Coach_name: ticket['Coach_name']
            })
        }
        response.send(utils.createResult(error, users))
    })
})

router.post('/',upload.single('thumbnail'),  (request, response) => {
    const {PNR_No,Ticket_no,No_of_seats,Source_Departure_Time,Destination_Arrival_Time,Fare,Coach_name} = request.body
   // const encryptedPassword = '' + cryptoJs.MD5(Password)
    const connection = db.connect()
    const statement = `insert into Ticket (PNR_No,Ticket_no,No_of_seats,Source_Departure_Time,Destination_Arrival_Time,Fare,Coach_name) values ('${PNR_No}',${Ticket_no},${No_of_seats},'${Source_Departure_Time}','${Destination_Arrival_Time}',${Fare},'${Coach_name}')`
    console.log(statement);
    connection.query(statement, (error, data) => {
        connection.end()
        console.log(error);
        response.send(utils.createResult(error, data))
    })
})

router.delete('/:Ticket_no', (request, response) => {
    const {Ticket_no} = request.params
    const connection = db.connect()
    const statement = `delete from Ticket where Ticket_no = ${Ticket_no}`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})

router.put('/:Ticket_no', (request, response) => {
    const {Ticket_no} = request.params
    const {Source_Departure_Time} = request.body
    const connection = db.connect()
    const statement = `update Ticket set Source_Departure_Time = '${Source_Departure_Time}' where Ticket_no = ${Ticket_no}`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})

/*router.post('/login', (request, response) => {
    const {Email, Password} = request.body
    //const encryptedPassword = '' + cryptoJs.MD5(password)
    const connection = db.connect()
    const statement = `select * from Admin where Email = '${Email}' and Password = '${Password}'`
    connection.query(statement, (error, users) => {
        connection.end()
        
        if (users.length == 0) {
            response.send(utils.createResult('user does not exist'))
        } else {
            const user = users[0]
            const info = {
                Email: user['Email'],
                Password: user['Password']
            }
            response.send(utils.createResult(null, info))
        }
    })
})
*/


module.exports = router