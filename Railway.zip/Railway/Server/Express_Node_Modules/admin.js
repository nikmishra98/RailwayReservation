const db = require('./db')
const express = require('express')
const utils = require('./utils')

const router = express.Router()

router.get('/', (request, response) => {
    const connection = db.connect()
    const statement = `select * from Admin`
    connection.query(statement, (error, data) => {
        connection.end()
        const users = []
        for (let index = 0; index < data.length; index++) {
            const admin = data[index]
            users.push({
                id: admin['AdminID'],
                firstname: admin['First_Name'],
                lastname: admin['Last_Name'],
                age: admin['Age'],
                gender: admin['Gender'],
                email: admin['Email'],
                password: admin['Password'],
                mobile: admin['MobileNumber'],
                address: admin['Address']
            })
        }
        response.send(utils.createResult(error, users))
    })
})

router.post('/', (request, response) => {
    const {firstname,lastname,age,gender,email,password,mobile,address} = request.body
   // const encryptedPassword = '' + cryptoJs.MD5(Password)
    const connection = db.connect()
    const statement = `insert into Admin (First_Name,Last_Name,Age,Gender,Email,Password,MobileNumber,Address) values ('${firstname}','${lastname}','${age}','${gender}','${email}', '${password}','${mobile}','${address}')`
    console.log(statement);
    connection.query(statement, (error, data) => {
        connection.end()
        console.log(error);
        response.send(utils.createResult(error, data))
    })
})

router.post('/login', (request, response) => {
    const {Email, Password} = request.body
    //const encryptedPassword = '' + cryptoJs.MD5(password)
    const connection = db.connect()
    const statement = `select * from Admin where Email = '${Email}' and Password = '${Password}'`
    connection.query(statement, (error, users) => {
        connection.end()
        
        if (users.length == 0) {
            response.send(utils.createResult('user does not exist'))
        } else {
            const user = users[0]
            const info = {
                Email: user['Email'],
                Password: user['Password']
            }
            response.send(utils.createResult(null, info))
        }
    })
})

router.post('/register', (request, response) => {
    const {First_Name,Last_Name,Age,Gender,Email,Password,MobileNumber,Address} = request.body
    //const encryptedPassword = '' + cryptoJs.MD5(password)
    const connection = db.connect()

    const statement1 = `select * from Admin where Email = '${Email}'`
    connection.query(statement1, (error, users) => {

        if (users.length == 0) {
            // user with the required email does not exist

            // insert a new record
            const statement = `insert into Admin (First_Name,Last_Name,Age,Gender,Email,Password,MobileNumber,Address) values ('${First_Name}','${Last_Name}',${Age},'${Gender}','${Email}', '${Password}','${MobileNumber}','${Address}')`
            connection.query(statement, (error, data) => {
                connection.end()
                response.send(utils.createResult(error, data))
            })
        } else {
            // user with email already exists
            connection.end()
            response.send(utils.createResult('Email exists. Please use another email.'))
        }


    })
})

module.exports = router