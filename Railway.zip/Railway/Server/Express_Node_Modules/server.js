const express = require('express')
const bodyParser = require('body-parser')


// import the routers
const routerAdmin = require('./admin')
const routerTrain = require('./train')
const routerTicket = require('./ticket')

const app = express()

// add middlewares

// for CORS
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.json())
app.use('/admin', routerAdmin)
app.use('/train',routerTrain)
app.use('/ticket',routerTicket)

app.listen(4000, '0.0.0.0', () => {
    console.log('server started  on port 4000')
})