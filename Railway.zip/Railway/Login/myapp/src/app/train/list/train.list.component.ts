import { Component, OnInit } from '@angular/core';
import { TrainService } from '../train.service';

@Component({
  selector: 'app-train-list',
  templateUrl: './train.list.component.html',
  styleUrls: ['./train.list.component.css']
})

export class TrainListComponent implements OnInit {
  trains = []

  constructor(private trainService: TrainService) {
    this.trainService
      .getAllTrains()
      .subscribe(response => {
        if (response['status'] == 'success') {
          this.trains = response['data']
        } else {
          console.log(response['error'])
        }
      })
  }

  getTrains() {
    this.trainService.get()
      .subscribe((response) => {
        if (response['status'] == 'success') {
          this.trains = response['data']
        } else {
          alert('error occured:')
          console.log(response['error'])
        }
      })
  }

  onDelete(Train_no: number) {

    const answer = confirm("Are you sure you want to delete this train?")
    if (answer) {
      this.trainService
        .delete(Train_no)
        .subscribe(response => {
          if (response['status'] == 'success') {
            alert('Category deleted successfully....!!!!')
            this.getTrains()
          } else {
            alert('error while deleing the category')
          }
        })
    }
  }
  ngOnInit() { }
}
