import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'

@Injectable()
export class TrainService{

    url = 'http://localhost:4000/train'

    constructor(private http: HttpClient){}

    get() {
      return this.http.get(this.url)
    }

    getTrain(){
        return this.http.get(this.url)
    }

    getAllTrains() {
        return this.http.get(this.url)
      }

    addTrain(Train_no: number, Train_name: string, No_of_coaches: number,
        Source: string, Destination: string, Duration: number
        ) {
  
      const body = new FormData()
      body.append('Train_no','' + Train_no)
      body.append('Train_name',Train_name)
      body.append('No_of_coaches','' + No_of_coaches)
      body.append('Source',Source)
      body.append('Destination',Destination)
      body.append('Duration',''+ Duration)
  
      return this.http.post(this.url, body)
    }

    delete(Train_no: number) {
      return this.http.delete(this.url + '/' + Train_no)
    }

}

