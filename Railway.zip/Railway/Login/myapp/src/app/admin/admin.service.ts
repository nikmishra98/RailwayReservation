import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserService {
    url = 'http://localhost:4000/admin'
  
  constructor(private http: HttpClient) { }

  login(Email: string, Password: string) {
    const body = {
      Email: Email,
      Password: Password
    }

    return this.http.post(this.url + '/login', body)
  }
  registerUser(First_Name: string,Last_Name: string,Age: number ,Gender: string,Email: string, Password: string,MobileNumber:string,Address:string) {
    const body = {
      First_Name: First_Name,
      Last_Name: Last_Name,
      Age: Age ,
      Gender: Gender,
      Email: Email, 
      Password: Password,
      MobileNumber: MobileNumber,
      Address: Address
    }

    return this.http.post(this.url + '/register', body)
  }

}

  
