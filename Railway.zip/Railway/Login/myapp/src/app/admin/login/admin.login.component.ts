import { Component, OnInit } from '@angular/core';
import { UserService } from '../admin.service';
import { Router } from '@angular/router';
import { TrainService } from 'src/app/train/train.service';

@Component({
  selector: 'app-login',
  templateUrl: './admin.login.component.html',
  styleUrls: ['./admin.login.component.css']
})

export class AdminLoginComponent {
  Email = ''
  Password = ''

  constructor(
    private router: Router,
    private userService: UserService) { }


  onLogin() {
    if (this.Email.length == 0) {
      alert('enter valid email')
    } else if (this.Password.length == 0) {
      alert('enter valid password')
    } else {
      this.userService
        .login(this.Email,this.Password)
        .subscribe(response => {
          if (response['status'] == 'success') {
            alert('authenticated')
            if(TrainService){
              this.router.navigate(['/app-train-list'])}
              else{
                this.router.navigate(['/app-ticket-list'])
              }
          } else {
            alert(response['error'])
          }
        })
    }
  }

}
