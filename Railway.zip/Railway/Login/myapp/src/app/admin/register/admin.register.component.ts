import { Component, OnInit } from '@angular/core';
import { UserService } from '../admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './admin.register.component.html',
  styleUrls: ['./admin.register.component.css']
})

export class AdminRegisterComponent {
  First_Name = ''
  Last_Name = ''
  Age = 0
  Gender = ''
  Email = ''
  Password = ''
  MobileNumber = ''
  Address = ''

  constructor(
    private router: Router,
    private userService: UserService) { }

  onRegister() {
    if (this.First_Name.length == 0) {
      alert('enter valid firstname')
    } else if (this.Last_Name.length == 0) {
      alert('enter valid lastname')
    } else if (this.Age == 0) {
        alert('enter age field')
    }else if (this.Gender.length == 0) {
        alert('enter valid gender')
      }else if (this.Email.length == 0) {
        alert('enter valid email')
      }else if (this.Password.length == 0) {
      alert('enter valid password')
    } else if (this.MobileNumber.length == 0) {
        alert('enter valid mobile number')
      }else if (this.Address.length == 0) {
        alert('enter valid address')
      }else {
      this.userService
        .registerUser(this.First_Name, this.Last_Name,this.Age,this.Gender,this.Email, this.Password,this.MobileNumber,this.Address)
        .subscribe(response => {
          console.log(response)
          if (response['status'] == 'success') {
            alert('registered successfully')
            this.router.navigate(['/app-login'])
          } else {
            alert(response['error'])
          }
        })
    }
  }
}
