import { Component, OnInit } from '@angular/core';
import { TicketService } from '../ticket.service';

@Component({
  selector: 'app-ticket-list',
  templateUrl: './ticket.list.component.html',
  styleUrls: ['./ticket.list.component.css']
})

export class TicketListComponent implements OnInit {
  tickets = []

  constructor(private ticketService: TicketService) {
    this.ticketService
      .getAllTicket()
      .subscribe(response => {
        if (response['status'] == 'success') {
          this.tickets = response['data']
        } else {
          console.log(response['error'])
        }
      })
  }

  getTickets() {
    this.ticketService.get()
      .subscribe((response) => {
        if (response['status'] == 'success') {
          this.tickets = response['data']
        } else {
          alert('error occured:')
          console.log(response['error'])
        }
      })
  }

  onDelete(Ticket_no: number) {

    const answer = confirm("Are you sure you want to delete this category?")
    if (answer) {
      this.ticketService
        .delete(Ticket_no)
        .subscribe(response => {
          if (response['status'] == 'success') {
            alert('Deleted ticket')
            this.getTickets()
          } else {
            alert('Error while deleting the category')
          }
        })
    }
  }

  ngOnInit() { }
}
