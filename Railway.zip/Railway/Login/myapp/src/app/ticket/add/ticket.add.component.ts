import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TicketService } from '../ticket.service';

@Component({
  selector: 'app-ticket-add',
  templateUrl: './ticket.add.component.html',
  styleUrls: ['./ticket.add.component.css']
})

export class TicketAddComponent implements OnInit {

  ticket = []

 PNR_No = ''    
 Ticket_no = 0 
 No_of_seats = 0
 Source_Departure_Time = ''       
 Destination_Arrival_Time = ''  
 Fare = 0
 Coach_name = ''

  constructor(
    private router: Router,
    private ticketService: TicketService) {}

  ngOnInit() { }

  onAdd() {
    if(this.PNR_No.length == 0){
        alert('Enter valid PNR number')
    }else if(this.Ticket_no == 0){
        alert('Enter a valid ticket number')
    }else if(this.No_of_seats == 0){
        alert('Enter valid coaches')
    }else if(this.Source_Departure_Time.length == 0){
        alert('Enter valid source departure time')
    }else if(this.Destination_Arrival_Time.length == 0){
        alert('Enter valid destination arrival time')
    }else if(this.Fare == 0){
        alert('Enter valid field')
    }else if(this.Coach_name.length == 0){
      alert('Enter valid coach name')
    } else {
       this.ticketService
      .addTicket(this.PNR_No, this.Ticket_no, this.No_of_seats, this.Source_Departure_Time, this.Destination_Arrival_Time, this.Fare,this.Coach_name)
      .subscribe(response => {
        if (response['status'] == 'success') {
          alert('Ticket added successfully....!!!!')
          this.router.navigate(['/app-ticket-list'])
        } else {
          console.log(response['error'])
        }
      })
   }  
  }
}

