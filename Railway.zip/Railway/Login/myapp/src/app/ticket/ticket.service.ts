import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'

@Injectable()
export class TicketService{
  
    url = 'http://localhost:4000/ticket'

    constructor(private http: HttpClient){}

    get() {
      return this.http.get(this.url)
    }

    put() {

    }

    getTicket(){
        return this.http.get(this.url)
    }

    getAllTicket() {
        return this.http.get(this.url)
      }

    addTicket(PNR_No: string,Ticket_no: number,No_of_seats: number,Source_Departure_Time: string,
        Destination_Arrival_Time: string,Fare: number,Coach_name: string
        ) {
  
      const body = new FormData()
      body.append('PNR_No',PNR_No)
      body.append('Ticket_no','' + Ticket_no)
      body.append('No_of_seats','' + No_of_seats)
      body.append('Source_Departure_Time',Source_Departure_Time)
      body.append('Destination_Arrival_Time',Destination_Arrival_Time)
      body.append('Fare',''+ Fare)
      body.append('Coach_name',Coach_name)
  
      return this.http.post(this.url, body)
    }

    delete(Ticket_no: number) {
      return this.http.delete(this.url + '/' + Ticket_no)

    }

}

