import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { UserService } from './admin/admin.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'
import { AdminLoginComponent } from './admin/login/admin.login.component';
import { AdminRegisterComponent } from './admin/register/admin.register.component';
import { RouterModule, Route } from '@angular/router'
import { TrainAddComponent } from './train/add/train.add.component';
import { TrainService } from './train/train.service';
import { TrainListComponent } from './train/list/train.list.component';
import { HomeComponent } from './home/home.component';
import { TicketAddComponent } from './ticket/add/ticket.add.component';
import { TicketListComponent } from './ticket/list/ticket.list.component';
import { TicketService } from './ticket/ticket.service'
//import { HomeService } from './home/home.service';


const routes: Route[] = [
 // { path: '', component: AppComponent },
  { path: '', component: HomeComponent },
  { path: 'app-login', component: AdminLoginComponent },
  { path: 'app-register', component: AdminRegisterComponent },
  { path: 'app-train-add', component: TrainAddComponent },
  { path: 'app-train-list', component: TrainListComponent },
  { path: 'app-ticket-list', component: TicketListComponent},
  { path: 'app-ticket-add', component: TicketAddComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    AdminLoginComponent,
    AdminRegisterComponent,
    TrainAddComponent,
    TrainListComponent,
    HomeComponent,
    TicketAddComponent,
    TicketListComponent
 ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [
    UserService,
    TrainService,
    TicketService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
